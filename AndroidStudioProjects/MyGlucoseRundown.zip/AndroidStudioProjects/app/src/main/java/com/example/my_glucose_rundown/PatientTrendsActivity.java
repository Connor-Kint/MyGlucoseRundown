package com.example.my_glucose_rundown;


import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

public class PatientTrendsActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    DrawerLayout drawerLayout;
    NavigationView navView;
    Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.patient_trends_activity);

        drawerLayout = findViewById(R.id.drawer_layout);
        navView = findViewById(R.id.nav_view);
        toolbar = findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(null);

        navView.bringToFront();
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.nav_drawer_open, R.string.nav_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        navView.setNavigationItemSelectedListener(this);
        navView.setCheckedItem(R.id.nav_trends);

        Spinner timeSpinner = (Spinner) findViewById(R.id.trend_time_period);

        ArrayAdapter<String> myAdapter = new ArrayAdapter<String>(com.example.my_glucose_rundown.PatientTrendsActivity.this, android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.times));
        myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        timeSpinner.setAdapter(myAdapter);
    }
    @Override
    public void onBackPressed() {
        if(drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        }
        else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch(menuItem.getItemId()) {
            case R.id.nav_home:
                Intent i7 = new Intent(PatientTrendsActivity.this, PatientHomePage.class);
                startActivity(i7);
                break;
            case R.id.nav_enter_reading:
                Intent i = new Intent(PatientTrendsActivity.this, EnterNewReadingActivity.class);
                startActivity(i);
                break;
            case R.id.nav_trends:
                break;
            case R.id.nav_prac_page:
                Intent i3 = new Intent(PatientTrendsActivity.this, PractitionerPageActivity.class);
                startActivity(i3);
                break;
            case R.id.nav_logout:
                Intent i4 = new Intent(PatientTrendsActivity.this, LogoutPageActivity.class);
                startActivity(i4);
                break;
            case R.id.nav_about:
                Intent i5 = new Intent(PatientTrendsActivity.this, AboutPageActivity.class);
                startActivity(i5);
                break;
            case R.id.nav_contact:
                Intent i6 = new Intent(PatientTrendsActivity.this, ContactPageActivity.class);
                startActivity(i6);
                break;
        }
        return true;
    }
}
