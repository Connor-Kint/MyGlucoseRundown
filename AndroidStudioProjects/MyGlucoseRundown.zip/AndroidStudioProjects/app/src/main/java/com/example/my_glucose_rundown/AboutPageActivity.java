package com.example.my_glucose_rundown;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class AboutPageActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.register);
    }
}
