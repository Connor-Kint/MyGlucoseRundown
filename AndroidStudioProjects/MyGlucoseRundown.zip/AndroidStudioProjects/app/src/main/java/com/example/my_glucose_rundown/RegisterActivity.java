package com.example.my_glucose_rundown;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.Switch;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {
    Boolean prac_position;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);

        Switch prac_switch = (Switch) findViewById(R.id.practitioner_switch);
        prac_switch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    prac_position = Boolean.TRUE;
                } else {
                    prac_position = Boolean.FALSE;
                }
            }
        });
    }
    public void onButtonClick(View v) {
        if (prac_position) {
            Intent i = new Intent(RegisterActivity.this, PractitionerRegisterActivity.class);
            startActivity(i);
        } else {
            Intent i = new Intent(RegisterActivity.this, PatientHomePage.class);
            startActivity(i);
        }
    }

}
