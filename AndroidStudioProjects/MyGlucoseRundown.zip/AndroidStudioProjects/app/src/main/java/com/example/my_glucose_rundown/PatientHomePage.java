package com.example.my_glucose_rundown;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;


import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.Exclude;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class PatientHomePage extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    //Variables
    DrawerLayout drawerLayout;
    NavigationView navView;
    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.patient_homepage);

        drawerLayout = findViewById(R.id.drawer_layout);
        navView = findViewById(R.id.nav_view);
        toolbar = findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(null);

        navView.bringToFront();
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.nav_drawer_open, R.string.nav_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        navView.setNavigationItemSelectedListener(this);
        navView.setCheckedItem(R.id.nav_home);

        String name = "Nash McConnell";

        TextView text = findViewById(R.id.hello_text);


        TextView seven_day_num = findViewById(R.id.num_seven_day_average);
        double num = 33.2;
        seven_day_num.setText(String.valueOf(num));

        text.setText("Hello, "+name+"!");
        // https://firebase.google.com/docs/database/android/read-and-write?utm_source=studio
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference();

        ValueEventListener postListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // Get Post object and use the values to update the UI
                text.setText("Hello, "+dataSnapshot.child("first_name").getValue()+" "+dataSnapshot.child("last_name").getValue()+"!");
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Getting Post failed, log a message
                Log.w("FragmentActivity", "loadPost:onCancelled", databaseError.toException());
                // ...
            }
        };
        myRef.child("users").child("1").addListenerForSingleValueEvent(postListener);

        //myRef.child("users").child("2").child("first_name").setValue(51.55);
        //myRef.child("users").child("2").child("last_name").setValue("Obama");
    }

    @Override
    public void onBackPressed() {
        if(drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        }
        else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch(menuItem.getItemId()) {
            case R.id.nav_home:
                break;
            case R.id.nav_enter_reading:
                Intent i = new Intent(PatientHomePage.this, EnterNewReadingActivity.class);
                startActivity(i);
                break;
            case R.id.nav_trends:
                Intent i2 = new Intent(PatientHomePage.this, PatientTrendsActivity.class);
                startActivity(i2);
                break;
            case R.id.nav_prac_page:
                Intent i3 = new Intent(PatientHomePage.this, PractitionerPageActivity.class);
                startActivity(i3);
                break;
            case R.id.nav_logout:
                Intent i4 = new Intent(PatientHomePage.this, LogoutPageActivity.class);
                startActivity(i4);
                break;
            case R.id.nav_about:
                Intent i5 = new Intent(PatientHomePage.this, AboutPageActivity.class);
                startActivity(i5);
                break;
            case R.id.nav_contact:
                Intent i6 = new Intent(PatientHomePage.this, ContactPageActivity.class);
                startActivity(i6);
                break;
        }
        return true;
    }

    public void onButtonClick(View v) {
        Intent i = new Intent(PatientHomePage.this, EnterNewReadingActivity.class);
        startActivity(i);
    }
}

class Post {

    public String uid;
    public String author;
    public String title;
    public String body;
    public int starCount = 0;
    public Map<String, Boolean> stars = new HashMap<>();

    public Post() {
        // Default constructor required for calls to DataSnapshot.getValue(Post.class)
    }

    public Post(String uid, String author, String title, String body) {
        this.uid = uid;
        this.author = author;
        this.title = title;
        this.body = body;
    }

    @Exclude
    public Map<String, Object> toMap() {
        HashMap<String, Object> result = new HashMap<>();
        result.put("uid", uid);
        result.put("author", author);
        result.put("title", title);
        result.put("body", body);
        result.put("starCount", starCount);
        result.put("stars", stars);

        return result;
    }

}

